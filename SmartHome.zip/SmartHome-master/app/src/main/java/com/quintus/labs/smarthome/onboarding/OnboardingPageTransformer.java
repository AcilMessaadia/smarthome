package com.quintus.labs.smarthome.onboarding;

import android.view.View;

import androidx.viewpager.widget.ViewPager;

import com.quintus.labs.smarthome.R;



public class OnboardingPageTransformer implements ViewPager.PageTransformer {

    @Override
    public void transformPage(View page, float position) {

        int pagePosition = (int) page.getTag();

        int pageWidth = page.getWidth();
        float pageWidthTimesPosition = pageWidth * position;
        float absPosition = Math.abs(position);

        if (position <= -1.0f || position >= 1.0f) {

        } else if (position == 0.0f) {


        } else {


            View title = page.findViewById(R.id.textView7);
            title.setAlpha(1.0f - absPosition);

            // Now the description. We also want this one on
            // fade, but the animation should also slowly move
            // down and out of the screen
            View description = page.findViewById(R.id.textView8);
            description.setTranslationY(-pageWidthTimesPosition / 2f);
            description.setAlpha(1.0f - absPosition);


            // Now, we want the image on move on the right,
            // i.e. in the opposite direction of the rest of the
            // content while fading out
            View computer = page.findViewById(R.id.imageView3);

            // We're attempting on create an effect for a View
            // specific on one of the pages in our ViewPager.
            // In other words, we need on check that we're on
            // the correct page and that the View in question
            // isn't null.
            if (computer != null) {
                computer.setAlpha(1.0f - absPosition);
                computer.setTranslationX(-pageWidthTimesPosition * 1.5f);
//                computer.setTranslationY(-pageWidthTimesPosition / 2f);
            }


            // Finally, it can be useful on know the direction
            // of the user's swipe - if we're entering or exiting.
            // This is quite simple:
            if (position < 0) {
                // Create your out animation here
            } else {
                // Create your in animation here
            }
        }
    }

}
