package com.quintus.labs.smarthome.ui.activity;
public class user {
    public String first_name,last_name,email,phone;
    public user(String first_name, String last_name, String email, String phone) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.email = email;
        this.phone = phone;
    }

    public user(boolean switchValestate, boolean switchPumpstate, boolean switchFanstate) {
    }
}
